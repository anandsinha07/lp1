import java.util.*;
import java.io.*;

public class prun_practice{

	public static int MIN = -1000;
	public static int MAX = 1000;
	public static int arr[] = new int[100];
	public static int j=0;

	public static int minimax(int depth, int index, boolean maxPlayer, int values[], int alpha, int beta){

		if(depth == 3)
			return values[index];

		if(maxPlayer){
			int best = MIN;
			for(int i=0; i<2; i++){
				int val = minimax(depth+1, 2*index+i, false, values, alpha, beta);
				best = Math.max(best, val);
				alpha = Math.max(alpha, best);

				if( alpha >= beta){
					break;
				}else{
					arr[j++]=val;
				}
			}

			return best;
		}
		else{
			int best = MAX;
			for(int i=0; i<2; i++){
				int val = minimax(depth+1, 2*index+i, true, values, alpha, beta);
				best = Math.min(best, val);
				beta = Math.min(beta, best);

				if( alpha >= beta){
					break;
				}else{
					arr[j++]=val;
				}
			}

			return best;
		}

	}

	public static void main(String args[]){
		int values[] = {3, 5, 6, 9, 1, 2, 0, -1};
		int opt = minimax(0, 0, true, values, MIN, MAX);
		System.out.println(opt);
		for(int i=0; i<j;i++)
			System.out.print(arr[i] + " ");
	}
}