#include<iostream>
#include<chrono>


using namespace std::chrono;

using namespace std;


int serial(int a[],int n)
{

int max=0;
	
	for(int i=0;i<n;i++)
	{
	
		if(a[i]>max)
		{

			max=a[i];
		}
	
	}
	return  max;

}

int main()
{

	cout<<"Enter the no of elements"<<endl;
	int n;
	cin>>n;

	int a[n];

	time_point<system_clock> start,end;

	
	

	for(int i=0;i<n;i++)
	{

		a[i]=i+1;
	
	}

	start=system_clock::now();	


	int maxi=serial(a,n);

	end=system_clock::now();


	duration<double> time=end-start;


	cout<<"The maxi element is "<<maxi<<endl;

	cout<<"the time required is "<<time.count()*1000000<<" micro seconds"<<endl;



}
