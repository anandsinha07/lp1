#include<iostream>

using namespace std;

#include<chrono>

using namespace std::chrono;

int sum(int a[],int n)
{

	int ans=0;

	for(int i=0;i<n;i++)
	{

		ans=ans+a[i];
	

	}


	return ans;

}




int main()
{

	cout<<"Enter the no of element"<<endl;	
	int n;
	cin>>n;


	int *a=new int[n];
	
	for(int i=0;i<n;i++)
	{


	a[i]=i+1;	


	}

	time_point<system_clock> start,end;

	start=system_clock::now();
	

	int ans=sum(a,n);
	
	end=system_clock::now();
	
	duration<double> time=end-start;

	cout<<"The time is "<<time.count()*1000000<<" mircor sec "<<endl;



	float mean=ans/(n*1.0f);

	cout<<"The mean is "<<mean<<endl;










}
