#include<iostream>
#include<chrono>


using namespace std::chrono;

using namespace std;


int serial(int a[],int n)
{

int min1=999999;
	
	for(int i=0;i<n;i++)
	{
	
		if(a[i]<min1)
		{

			min1=a[i];
		}
	
	}
	return  min1;

}

int main()
{

	cout<<"Enter the no of elements"<<endl;
	int n;
	cin>>n;

	int a[n];

	time_point<system_clock> start,end;

	
	

	for(int i=0;i<n;i++)
	{

		a[i]=n-i+1;
	
	}

	start=system_clock::now();	


	int mini=serial(a,n);

	end=system_clock::now();


	duration<double> time=end-start;


	cout<<"The minimum element is "<<mini<<endl;

	cout<<"the time required is "<<time.count()*1000000<<" micro seconds"<<endl;



}
