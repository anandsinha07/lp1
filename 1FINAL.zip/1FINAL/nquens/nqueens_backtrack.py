matrix = [[0 for i in range(100)] for i in range(100)]
row = [0 for i in range(100)]
fwd = [0 for i in range(100)]
bwd = [0 for i in range(100)]

def checkRow(row, n):
    for i in range(1, n+ 1):
        if matrix[row][i] == 1:
            return True
    return False

def checkDiagonal(row, col, n):
    i=1
    while row+i<n+1 or row-i>0 or col+i<n+1 or col-i>0:
        if row+i<n+1 and col+i<n+1 and matrix[row+i][col+i]==1:
            return True
        if row+i<n+1 and col-i>0 and matrix[row+i][col-i]==1:
            return True
        if row-i>0 and col+i<n+1 and matrix[row-i][col+i]==1:
            return True
        if row-i>0 and col-i>0 and matrix[row-i][col-i]==1:
            return True
        i=i+ 1;
    return False

def nqueens(n, col):
    for row in range(1, n+ 1):
        if checkRow(row, n) == False and checkDiagonal(row, col, n) == False:
            matrix[row][col] = 1
            if col == n:
                return True
            flag = nqueens(n, col+ 1)
            if flag == False:
                matrix[row][col] = 0
            else:
                return True
    return False


if __name__ == "__main__":
    n = int(input("Enter n: "))
    nqueens(n, 1)
    for i in range(1, n+ 1):
        print(matrix[i][1:n+ 1])

