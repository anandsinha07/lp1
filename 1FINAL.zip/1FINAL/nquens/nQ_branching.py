
matrix = [[0 for i in range(1, 100)]for i in range(1, 100)]
row = [0 for i in range(1, 100)]
fwd = [0 for i in range(100)]
bwd = [0 for i in range(100)]


def check(row1, col1, n):
	return row[row1] == True or fwd[row1+col1]==True or bwd[2*n-1+row1-col1]==True

def mark(row1, col1, n, arg):
	row[row1] = arg
	fwd[row1+col1] = arg
	bwd[2*n-1+row1-col1] = arg

def nqueens_branching(n, col):
	for row in range(1, n+1):
		if check(row, col, n) == False:
			matrix[row][col] = 1
			mark(row, col, n, True)
			if col == n:
				return True
			flag = nqueens_branching(n, col+1)
			if flag == False:
				matrix[row][col] = 0
				mark(row, col, n, False)
			else:
				return True
	return False

if __name__ == "__main__":
	n = int(input("Enter n :"))
	nqueens_branching(n, 1)
	for i in range(1, n+1):
		print(matrix[i][1:n+1])