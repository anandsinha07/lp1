#include <iostream>
#include <omp.h>
#include <chrono>

using namespace std;
using namespace std::chrono;

void series(int a[], int n){
    
    for(int i=0; i<n - 1; i++){
        for(int j=0; j<n-1; j++){
            if(a[j] > a[j+ 1]){
                int temp = a[j];
                a[j] = a[j+1];
                a[j+1] = temp;
            }
        }
    }
    
}

void parallel(int b[], int n){
    
    omp_set_num_threads(2);
    
    int first =0;
    for(int i=0; i<n; i++){
        first = i%2;
        #pragma omp parallel for default(none), shared(b, first, n)
        for(int j=first; j<n-1; j=j+2){
            if(b[j]>b[j+1]){
                int temp= b[j];
                b[j] = b[j+1];
                b[j+1] = temp;
            }
        }
        
    }
    
}

int main(){
    
    cout<<"enter size : "<<endl;
    int n;
    cin>>n;
    
    int a[n], b[n];
    for(int i=0; i<n; i++){
        a[i] = b[i] = n - i;
    }
    
    time_point <system_clock> start, end;
    start = system_clock::now();
    series(a, n);
    end = system_clock::now();
    duration<double> time = end - start;
    cout<<"Series time : "<<time.count()*1000<<endl;
    
    start = system_clock::now();
    parallel(b, n);
    end = system_clock::now();
    time = end - start;
    
    cout<<"Parallel time : "<<time.count()*1000<<endl;
    
    cout<<endl;
    
    
}
