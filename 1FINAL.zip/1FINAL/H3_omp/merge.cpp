
#include <iostream>
#include <omp.h>
#include <chrono>

using namespace std;
using namespace std::chrono;

void merge(int a[], int s1, int e1, int s2, int e2){
    
    int *temp = new int[e2 - s1 + 1];
    int i1 = s1;
    int i2 = s2;
    int k=0;
    while(i1<=e1 && i2<=e2){
        if(a[i1]<a[i2])
            temp[k++] = a[i1++];
        else
            temp[k++] = a[i2++];
    }
    
    while(i1<=e1){
        temp[k++] = a[i1++];
    }
    
    while(i2<=e2){
        temp[k++] = a[i2++];
    }
    
    for(i1=s1,i2=0; i1<=e2; i1++, i2++){
        a[i1] = temp[i2];
    }
}

void mergeSerial(int a[], int l, int r){
    if(l<r){
        int m = (l + r)/2;
        mergeSerial(a, l, m);
        mergeSerial(a, m+1, r);
        merge(a, l, m, m+1, r);
    }
}

void mergeParallel(int b[], int l, int r){
    
    if(l<r){
        int m = (l+r)/2;
        #pragma omp parallel sections
        {
            #pragma omp section
            {
                mergeSerial(b, l, m);
            }
            
            #pragma omp section
            {
                mergeSerial(b, m+1, r);
            }
        }
        
        merge(b, l, m, m+1, r);
    }
    
}

int main(){
    cout<<"enter size : "<<endl;
    int n;
    cin>>n;
    int *a = new int[n];
    int *b = new int[n];
    
    for(int i=0; i<n; i++){
        a[i] = b[i] = n - i;
    }
    
    time_point <system_clock> start, end;
    start = system_clock::now();
    mergeSerial(a, 0, n-1);
    end = system_clock::now();
    duration<double> time = end - start;
    
    cout<<"serial time : "<<time.count()*1000 <<endl;
    
    omp_set_num_threads(2);
    
    start = system_clock::now();
    mergeParallel(b, 0, n-1);
    end = system_clock::now();
    time = end - start;
    cout<<"parallel time is : "<<time.count()*1000<<endl;
    
//    for(int i=0; i<n; i++){
//        cout<<b[i]<<" ";
//    }
//
//    cout<<endl;
//
}
