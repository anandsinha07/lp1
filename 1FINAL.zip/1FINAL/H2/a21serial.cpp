#include<iostream>
#include<chrono>


using namespace std::chrono;


using namespace std;


void add(int *a,int *b,int *c,int n)
{


	for(int i=0;i<n;i++)
	{

	    c[i]=a[i]+b[i];
		

	}

}



int main()
{

	cout<<"Enter the elements"<<endl;
	int n;
	cin>>n;

	int *a=new int[n];
	int *b=new int[n];
	int *c=new int[n];
	
	for(int i=0;i<n;i++)
	{

		a[i]=i+1;
		b[i]=i+1;

	}

	time_point<system_clock> start,end;
	

	start=system_clock::now();
	
	add(a,b,c,n);

	end=system_clock::now();

	duration<double> time=end-start;

	cout<<"The time req is "<<time.count()*10000000<<endl;;



	for(int i=0;i<5;i++)
	{

		cout<<c[i]<<endl;

	}
}
