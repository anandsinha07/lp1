#include<iostream>
#include<chrono>


using namespace std;
using namespace std::chrono;

void multiply(int *a,int *b,int *c,int n)
{

	for(int i=0;i<n;i++)
	{

		int sum=0;
		for(int j=0;j<n;j++)
		{

			sum=sum+a[i*n+j]*b[j];


		}


		c[i]=sum;

	}
} 

int main()
{

	cout<<"Enter the dimension"<<endl;
	int n;
	cin>>n;



	int *a=new int[n*n],*b=new int[n],*c=new int[n];

	
	time_point<system_clock> start,end;


	for(int i=0;i<n;i++)
	{

		for(int j=0;j<n;j++)

		{

			a[i*n+j]=3+i;


		}

		b[i]=2+i;

	}


	start=system_clock::now();
	

	multiply(a,b,c,n);


	end=system_clock::now();

	duration<double> time=end-start;


	cout<<"The time required is "<<time.count()*1000000<<" micro sec"<<endl;
		
	
	for(int i=0;i<n;i++)
	{

		//cout<<c[i]<<" ";

	}


}
