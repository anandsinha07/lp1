#include<iostream>

#include<chrono>


using namespace std;
using namespace std::chrono;




void multiply(int *a,int *b,int *c,int n)
{
	

	for(int i=0;i<n;i++)
	{

		for(int j=0;j<n;j++)
		{

			int sum=0;
			for(int k=0;k<n;k++)

			{

				sum=sum+a[i*n+k]*b[k*n+j];
			

			}			
	
			c[i*n+j]=sum;

		}
	
	}
}



int main()
{
	cout<<"Enter the dimension"<<endl;

	int n;	
	cin>>n;

	int *a=new int[n*n],*b=new int[n*n],*c=new int[n*n];

	for(int i=0;i<n;i++)
	{

		for(int j=0;j<n;j++)	
		{

			a[i*n+j]=3+i;
			b[i*n+j]=2+j;


		}	

	


	}

	time_point<system_clock> start,end;

	start=system_clock::now();
	

	multiply(a,b,c,n);

	end=system_clock::now();

	duration<double> time=end-start;


	cout<<"the time is "<<time.count()*1000000<<" micro sec"<<endl;	

	
	for(int i=0;i<10;i++)
	{
	
		for(int j=0;j<10;j++)
		{


			cout<<c[i*n+j]<<" ";
			


		}


		cout<<endl;


	}













}
