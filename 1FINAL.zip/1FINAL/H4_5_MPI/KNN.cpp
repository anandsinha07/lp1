#include<mpi.h>
//-----------------------
#include<iostream>
//--------------------
#include<fstream>
#include<string>
//-----------------------
#include<vector>
//------------------
#include<cmath>
//---------------------
#include<stdlib.h>
#include<cstring>
//----------------------
#include<map>
#include<set>

using namespace std;

class Instance {
    public:
    double r, g, b;
    int skin;
    
    Instance(double r, double g, double b, int skin){
        this->r = r;
        this->g = g;
        this->b = b;
        this->skin = skin;
    }
    double calc(double R, double G, double B) {
        return sqrt((r-R)*(r-R) + (g-G)*(g-G) + (b-B)*(b-B));
    }
};

class TestInstance {
    public:
    double r, g, b;
    TestInstance(double r, double g, double b) {
        this->r = r;
        this->g = g;
        this->b = b;
    }
};

vector<string> split(string a, char e) {
    vector<string> s;
    string cur;
    for(int i = 0; i < a.size(); i++) {
        if(a[i] != e)
        cur.push_back(a[i]);
        else {
            s.push_back(cur);
            cur.clear();
        }
    }
    
    if(cur != "")
    s.push_back(cur);
    return s;
}

vector<Instance> instances;
int k;

int returnClassforobj(double r,double g,double b,set<double>distances,map<double,int>distanceToClass) {
    for(int i=0;i<instances.size();i++) {
        double distance = instances[i].calc(r, g, b);
        distances.insert(distance);
        distanceToClass.insert(std :: pair<double,int>(distance,instances[i].skin));
    }
    int class_1 = 0, class_2 = 0;
    set <double>::iterator it = distances.begin();
    
    while(class_1 != k && class_2 != k) {
        if(distanceToClass.find(*it)->second == 1)
        class_1++;
        else if(distanceToClass.find(*it)->second == 2)
        class_2++;
        
        it++;
    }
    if(class_1 == k)
    return 1;
    else if(class_2 == k)
    return 2;
}
int main() {
    MPI_Init(NULL,NULL);
    int world_size, rank;
    MPI_Comm_size(MPI_COMM_WORLD,&world_size);
    MPI_Comm_rank(MPI_COMM_WORLD,&rank);
    
    MPI_Request requests[(world_size-1)*3];
    MPI_Status statuses[(world_size-1)*3];
    
    string line;
    ifstream myfile("training.txt");
    if(myfile.is_open()) {
        while(getline(myfile, line)) {
            vector<string> parts = split(line, ' ');
            Instance instance(atof(parts[0].c_str()), atof(parts[1].c_str()), atof(parts[2].c_str()), atoi(parts[3].c_str()));
            instances.push_back(instance);
        }
        myfile.close();
    }
    
    double minR = instances[0].r, maxR = minR;
    double minB = instances[0].b, maxB = minB;
    double minG = instances[0].g, maxG = minG;
    double curr, res, r, g, b;
    
    for(int i = 1; i < instances.size(); i++)   {
        maxR = max(maxR, instances[i].r);
        minR = min(minR, instances[i].r);
        maxG = max(maxG, instances[i].g);
        minG = min(minG, instances[i].g);
        maxB = max(maxB, instances[i].b);
        minB = min(minB, instances[i].b);
    }
    
    for(int i = 0;i < instances.size(); i++) {
        instances[i].r = (instances[i].r-minG)/(maxG - minG);
        instances[i].g = (instances[i].g-minG)/(maxG - minG);
        instances[i].b = (instances[i].b-minG)/(maxG - minG);
    }
    
    ifstream new_file("test_.txt");
    string new_line;
    k = sqrt(instances.size());
    
    vector<TestInstance>test_instances;
    map <double, int> distanceToClass;
    set <double> distances;
    double start, end;
    if(rank == 0) {
        if(new_file.is_open()) {
            while(getline(new_file, new_line)) {
                vector<string> parts = split(new_line, ' ');
                double r = atof(parts[0].c_str()), g = atof(parts[1].c_str()), b = atof(parts[2].c_str());
                r = (r - minR)/(maxR - minR);
                g = (g - minG)/(maxG - minG);
                b = (b - minB)/(maxB - minB);
                
                TestInstance new_instance(r, g, b);
                test_instances.push_back(new_instance);
            }
        }
        
        start = MPI_Wtime();
        int index = 1;
        for(int i = 0; i < test_instances.size(); i++) {
            double r = test_instances[i].r, g = test_instances[i].g, b = test_instances[i].b;
            MPI_Isend(&r, 1, MPI_DOUBLE, i, 0, MPI_COMM_WORLD, requests+index);
            MPI_Isend(&g, 1, MPI_DOUBLE, i, 0, MPI_COMM_WORLD, requests+index+1);
            MPI_Isend(&b, 1, MPI_DOUBLE, i, 0, MPI_COMM_WORLD, requests+index+2);
            index += 3;
        }
        double r = test_instances[0].r, g = test_instances[0].g, b = test_instances[0].b;
        int class_predicted = returnClassforobj(r, g, b, distances, distanceToClass);
        cout << "Class for " << rank+1 << "object is: " << class_predicted << endl;
    }
    else {
        double r, g, b;
        MPI_Irecv(&r, 1, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD, requests+rank+1);
        MPI_Irecv(&g, 1, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD, requests+rank+2);
        MPI_Irecv(&b, 1, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD, requests+rank+3);
        
        MPI_Wait(requests+rank+1, statuses+rank+1);
        MPI_Wait(requests+rank+2, statuses+rank+2);
        MPI_Wait(requests+rank+3, statuses+rank+3);
        int class_predicted = returnClassforobj(r, g, b, distances, distanceToClass);
        cout << "Class for " << rank+1 << "object is: " << class_predicted << endl;
    }
    MPI_Barrier(MPI_COMM_WORLD);
    if(rank==0) {
        end = MPI_Wtime();
        cout << "Elapsed time" << (start-end) << "seconds";
    }
    MPI_Finalize();
    return 0;
}
