#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<mpi.h>

void printInorder(int* arr, int start, int end, int my_id) {
    if(start > end)
    return;
    printInorder(arr, start*2+1, end, my_id);
    printf("%d:%d\t ", my_id, arr[start]);
    printInorder(arr, start*2+2, end, my_id);
}
/*
 In order to prove that parallel programming is good over serial one we require large graph(for smaller graphs difference is not appreciable
 so having large graph is our first need).
 
 The idea is graph will have root node and 4 children. Each child will be a BST with say 1024 nodes. Nodes may increase as per need.
 now for each child BST say for 1st child , node data will be 1-1024
 for 2nd child = 1025-2048
 for 3rd child = 2049-3072
 and for 4th child = 3073-4096
 
 constructing BST is 1st challenege.
 buildTree function constructs a BST from values contained in array(must be sorted and withour duplicates) and returns root of BST to caller.
 we have called these function 4 times i.e. for every child BST with appropriate values in array 'arr'.
 */
void buildTree(int* arr,int start,int end,int* tree,int k,int offset,int N) {
    if(start <= end && k <= N-1) {
        int mid = (end+start+1)/2;
        tree[k] = mid+offset;
        buildTree(arr, start, mid-1, tree, k*2+1, offset, N);
        buildTree(arr, mid+1, end, tree, k*2+2, offset, N);
    }
}

int main(int argc, char const *argv[]) {
    int N = 4;
    int arr[N], tree[N], slaveArray[N], i, turns = 1 ,children = 4, ierr;
    MPI_Status status;
    int my_id, num_procs, received, send_data_tag, root_process;
    
    double start,finish;
    ierr = MPI_Init(&argc, &argv);
    start = MPI_Wtime();
    ierr = MPI_Comm_rank(MPI_COMM_WORLD, &my_id);
    ierr = MPI_Comm_size(MPI_COMM_WORLD, &num_procs);
    
    if(my_id == 0) {
        turns = 1;
        /*
         for loop is basically constructing every child branch and immediately giving it to slave.
         One may find it weird. If you wish you can maintain separate 2D array to store every child array and then apply another for loop to send each
         child to slave. It basically involves extra memory space and unnecessary time.
         */
        for(; turns<=children; turns++) {
            int offset = (turns-1)*N;
            buildTree(arr, 0, N, tree, 0, offset, N);
            ierr = MPI_Send(&N, 1, MPI_INT, turns-1, send_data_tag, MPI_COMM_WORLD);
            ierr = MPI_Send(&tree, N, MPI_INT, turns-1, send_data_tag, MPI_COMM_WORLD);
        }
    }
    else {
        ierr = MPI_Recv(&received, 1, MPI_INT, root_process, send_data_tag, MPI_COMM_WORLD, &status);
        ierr = MPI_Recv(&slaveArray, received, MPI_INT, root_process, send_data_tag, MPI_COMM_WORLD, &status);
        printInorder(slaveArray, 0, received-1, my_id);
    }
    
    finish = MPI_Wtime();
    printf("Execution time = %f seconds\n",(finish-start));
    MPI_Finalize();
}
