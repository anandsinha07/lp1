import re
import sqlite3
from collections import Counter
from string import punctuation
from math import sqrt
 
# initialize the connection to the database
connection = sqlite3.connect('chatbot1.sqlite')
cursor = connection.cursor()
# create the tables needed by the program
create_table_request_list = [
    'CREATE TABLE words(key TEXT, value TEXT)',
]
for create_table_request in create_table_request_list:
    try:
        cursor.execute(create_table_request)
    except:
        pass

def get_id(entityName, text):
    """Retrieve an entity's unique ID from the database, given its associated text.
    If the row is not already present, it is inserted.
    The entity can either be a sentence or a word."""
    cursor.execute('SELECT value FROM ' + entityName + ' WHERE  key = ?', (text,))
    row = cursor.fetchone()
    if row:
    	return row[0]
    return False

B = 'Hello!'
print('B: ' + B)	
while True:
    # output bot's message
    # ask for user input; if blank line, exit the loop
    H = raw_input('H: ').strip()
    if H == '':
        break

    ans = get_id('words', H)
    if ans == False:
    	B = H
    	print('B: '+B+' Fetch')
    	H = raw_input('H: ').strip()
    	if H == '':
	        break

    	cursor.execute('INSERT INTO words VALUES (?, ?)', (B, H))
    	connection.commit()
    else :
    	print ('B: '+ans)
