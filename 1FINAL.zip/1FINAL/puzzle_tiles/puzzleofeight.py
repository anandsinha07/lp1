import math
import random

GoalState = [[1, 2, 3],
             [4, 5, 6],
             [7, 8, 0]]

def index(item, sequence) :
    if item in sequence :
        return sequence.index(item) 
    return -1

class EightPuzzle :

    def __init__ (self):
        self.hval = 0
        self.depth = 0
        self.parent = None
        self.Adj_mat = []

        for i in range(3):
            self.Adj_mat.append(GoalState[i][:])
    
    def __eq__(self, other):
        if self.__class__ != other.__class__:
            return False
        return self.Adj_mat == other.Adj_mat

    def __str__(self):
        res = ''
        for row in range(3):
            res += ' '.join(map(str, self.Adj_mat[row]))+'\r\n'
        return res

    def find(self, value) :
        if value > 8 or value < 0:
            raise Exception("Value out of Range.")
        for i in range(3) :
            for j in range(3) :
                if self.Adj_mat[i][j] == value :
                    return i, j

    # Get the possible moves.
    def GetLegalMoves (self):
        row, col = self.find(0)
        free = []

        if row > 0 :
            free.append((row-1, col))
        if col > 0 :
            free.append((row, col-1))
        if row < 2 :
            free.append((row+1, col))
        if col < 2 :
            free.append((row, col+1))

        return free

    def Clone(self) :
        p = EightPuzzle()
        for i in range(3) :
            p.Adj_mat[i] = self.Adj_mat[i][:]
        return p
    
    def swap(self, posa, posb) :
        temp = self.Adj_mat[posa[0]][posa[1]]
        self.Adj_mat[posa[0]][posa[1]] = self.Adj_mat[posb[0]][posb[1]]
        self.Adj_mat[posb[0]][posb[1]] = temp
    
    def GenerateMoves(self):
        free = self.GetLegalMoves()
        zero = self.find(0)
        
        def SwapAndClone(a, b):
            p = self.Clone()
            p.swap(a, b)
            p.depth = self.depth + 1
            p.parent = self
            return p
        return map(lambda pair: SwapAndClone(zero, pair), free)

    def GenerateSolution(self, path):
        if self.parent == None:
            return path
        else:
            path.append(self)
            return self.parent.GenerateSolution(path)

    def Solve (self, h):
        
        def isSolved(puzzle) :
            return puzzle.Adj_mat == GoalState
        
        Open = [self]
        Closed = []
        movecount = 0
        while len(Open) > 0:
            x = Open.pop(0)
            movecount += 1
            if isSolved(x):
                if len(Closed) > 0:
                    return x.GenerateSolution([]), movecount
                else :
                    return [x], 0

            Successor = x.GenerateMoves()

            OpenIndex, ClosedIndex = -1, -1

            for move in Successor :
                OpenIndex = index(move, Open)
                ClosedIndex = index(move, Closed)
                hval = h(move)
                fval = hval+move.depth

                if OpenIndex == -1 and ClosedIndex == -1:
                    move.hval = hval
                    Open.append(move)
                
                elif OpenIndex > -1:
                    copy = Open[OpenIndex]
                    if fval < copy.hval + copy.depth :
                        copy.hval = hval
                        copy.parent = move.parent
                        copy.depth = move.depth

                elif ClosedIndex > -1 :
                    copy = Closed[ClosedIndex]
                    if fval < copy.hval + copy.depth :
                        move.hval = hval
                        Closed.remove(copy)
                        Open.append(move)

            Closed.append(x)
            Open = sorted(Open, key=lambda p: p.hval+p.depth)
    
        return [], 0

    def shuffle(self, step_count):
        for i in range(step_count):
            row, col = self.find(0)
            free = self.GetLegalMoves()
            target = random.choice(free)
            self.swap((row, col), target)            
            row, col = target

def h_manhattan(puzzle):
    count = 0
    for i in range (3) :
        for j in range (3) :
            if puzzle.Adj_mat[i][j] != GoalState[i][j] :
                count += 1
    return count
    
if __name__ == "__main__" :
    p = EightPuzzle()
    p.shuffle(20)
    print(p)

    path, count = p.Solve(h_manhattan)
    path.reverse()
    for i in path: 
        print(i)